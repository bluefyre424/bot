---
name: New item alias
about: Suggest a new alias to be added for an item!
title: "[Item Alias] <item name>: <your alias>"
labels: i showed u my issue pls respond
assignees: ''

---

**The item**
Which item would you like the alias to be added for? E.g Ship: Betty

**New alias**
How would you like to be able to refer to the item?

*(optional)* **Your discord tag**
If you'd like to be credited for your new alias in the bot's update announcements, you can give your discord tag here!
