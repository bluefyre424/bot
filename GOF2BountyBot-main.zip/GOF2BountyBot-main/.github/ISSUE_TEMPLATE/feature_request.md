---
name: Feature request
about: Suggest an idea for the bot!
title: "[Feature]"
labels: i showed u my issue pls respond
assignees: ''

---

*(optional)* **Is your feature request related to a problem?**
If your idea solves a problem with the bot, tell us about it here E.g,: It's not fair when...

**Describe the solution you'd like**
What would your ideal solution look like? E.g: I'd like to be able to...

*(optional)* **Additional details**
Any extra details, context, screenshots, mockups, etc. etc.

*(optional)* **Your discord tag**
If you'd like to be credited for your idea in the bot's update announcements, you can give your discord tag here!
